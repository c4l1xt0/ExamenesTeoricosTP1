package ejercicio2;

public class FantasticFour {
	
	protected int x = 0;
	
	public FantasticFour () {
		x = 100;
	}
	
	public FantasticFour ( int number ) {
		x += number ;
	}
	
	public void printX () {
		System.out.println(x) ;
	}
}
