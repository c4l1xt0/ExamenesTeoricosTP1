package ejercicio2;

public class Ejercicio2 {
	public static void main(String[] args) {
		// Apartado 1
		InvisibleWoman iw = new InvisibleWoman ();
		iw = new InvisibleWoman ();
		
		Thing t = new Thing ();
		t = new Thing (5);
		
		
		//el metodo this hace llamar al constructor padre
		iw.printX();
		t.printX();
		// Apartado 2
		
		/*esta mal porque no se adapta al constructor
		InvisibleWoman iw = new InvisibleWoman (5);
		iw.printX();*/
		
		MiniThing mt = new MiniThing ("Soy el hijo de Thing!");
		mt = new MiniThing ();
		mt.printX();
		
		// Apartado 3
		/*ESTADUPLICADO
		InvisibleWoman iw = new InvisibleWoman ();*/
		iw.printX();
		/*ESTADUPLICADO
		Thing t = new Thing (3);*/
		t.printX();
		/*ESTA DUPLICADO
		MiniThing mt = new MiniThing ("Soy el hijo de Thing!");*/
		mt.printX();
		
		mt = new MiniThing (10);
		mt.printX();
		mt = new MiniThing (0);
		mt.printX();
		}
}
