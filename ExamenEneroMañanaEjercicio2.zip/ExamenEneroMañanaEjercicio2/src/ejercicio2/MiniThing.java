package ejercicio2;

public class MiniThing extends Thing{ 
	
	public MiniThing () {
	}
	
	public MiniThing ( String name ) {
		System . out . println ( "MiniThing: " + name + "[" +x+ "]" ) ;
	}
	
	public MiniThing ( int x) {
		this . x += x ;
	}

}
