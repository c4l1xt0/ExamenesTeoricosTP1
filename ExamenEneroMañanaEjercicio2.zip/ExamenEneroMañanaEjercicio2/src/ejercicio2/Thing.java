package ejercicio2;

public class Thing extends FantasticFour{
	
	public Thing () {
		super (10) ;
	}
	
	
	public Thing ( int x) {
		this.x += x * 2 ;
	}
}
