package ejercicio2;

public class InvisibleWoman extends FantasticFour {

}
