package ejercicio1;

public abstract class Persona implements AccionAlumno {
	String nombre ;
	String dni ;
	public Persona () {
	}
	public Persona ( String nombre , String dni ) {
		this . nombre = nombre ;
		this . dni = dni ;
	}
	public abstract void matricularse (String asignatura );
	
	public void hacerExamen ( String asignatura ) {
		System.out.println (nombre + " no puede examinarse" ) ;
	}
}
