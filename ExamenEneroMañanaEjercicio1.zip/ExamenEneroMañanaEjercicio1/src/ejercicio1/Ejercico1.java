package ejercicio1;

public class Ejercico1 {

	public static void main(String[] args) {
		AccionAlumno vector [] = new AccionAlumno [10];
		vector[0] = new Alumno ("AL_01", "Peter", "12345");
		vector[1] = new Alumno ("AL_03", "Mary", "678910");
		// Apartado 1
		
		//NO PUEDES CREAR UNA INSTANCIIA DE UNA CLASE ABSTRACTA O DE UNA INTERFAZ
		/*Persona persona = new Persona ();
		persona.hacerExamen("TP1");*/
		
		// Apartado 2
		//ACCION ALUMNNO NO ES UNA PERSONA
		/*Persona persona = vector[0];
		persona.saludar();*/
		
		
		/*AccionAlumno no es un alumno
		Alumno alumno = vector[1];
		alumno.hacerExamen ("TP1");*/
		// Apartado 3
		
		
		
		Alumno erasmus = new AlumnoErasmus("ERA_0123", "Chris", "24689");
		erasmus.saludar();
		erasmus.hacerExamen("FP2");
		// Apartado 4
		AccionAlumno accion = vector[1];
		Alumno al = (Alumno) vector[0];
		accion.saludar();
		al.saludar();
		accion.matricularse("TP2");
		al.matricularse("TP2");
		accion.hacerExamen("TP2");
		al.hacerExamen("TP2");
		}
	
}
