package ejercicio1;

public interface AccionAlumno {
	public void matricularse (String asignatura );
	public void hacerExamen ( String asignatura ) ;
	
	public default void saludar () {
		System . out . println ( "HOLA!" ) ;
	}
}
