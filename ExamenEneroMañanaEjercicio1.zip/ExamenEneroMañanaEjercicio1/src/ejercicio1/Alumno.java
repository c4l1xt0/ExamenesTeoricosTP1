package ejercicio1;

public class Alumno extends Persona{
	protected String matriculaID ;
	public Alumno ( String matriculaID , String nombre , String dni ) {
	super (nombre , dni ) ;
	this . matriculaID = matriculaID ;
	}
	public void matricularse (String asignatura ) {
	System . out . println (nombre + "[" + matriculaID + "] se matricula en " +
	asignatura );
	}
	
	public void hacerExamen ( String asignatura ) {
	System . out . println (nombre + "[" + matriculaID + "] se examina de " +
	asignatura );
	}
	public void saludar () {
	System . out . println ( "HOLA! me llamo: " + nombre ) ;
	}
}
