package ejercicio1;

public class AlumnoErasmus extends Alumno {
	
	public AlumnoErasmus ( String matriculaID , String nombre , String dni ) {
		super ( matriculaID , nombre , dni ) ;
	}
	
	public void hacerExamen ( String asignatura ) {
		System . out . println ( "Alumno ERASMUS:" + nombre + "[" + matriculaID + "]"+ "se examina de" + asignatura );
	}
	
	public void saludar (Object o) {
		System . out . println ( "HOLA! Soy alumno Erasmus y me llamo: " + nombre ) ;
	}
	
}
