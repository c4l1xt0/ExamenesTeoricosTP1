
public class PortalException extends Exception {

	
	public PortalException ( String name ) {
			super (name ) ;
	}
}
