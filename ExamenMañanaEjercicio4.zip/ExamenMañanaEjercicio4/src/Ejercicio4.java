
public class Ejercicio4 {

	public static void main ( String [ ] args ) {
		try{
		// Apartado 1
		entrarEnPortal ( "Wheatley" ) ;
		//Apartado 2
		entrarEnPortal ( "GLaDOs" ) ;
		}	
		catch (Exception e) {
			System . out . println ( "Excepci�n capturada en Aperture Science" ) ;
		}
			System . out . println ( "Saliendo de Aperture: The cake is a lie!" ) ;
		}
	
	public static void entrarEnPortal ( String OSname) throws PortalException {
		try {
			if (OSname.equals ( "GLaDOs" )){
			try {
				for ( int i =2; i >=0; i --)
					portal1 (OSname , i ) ;
			} catch (NullPointerException e){
				System . out . println ( "Glados es null... R�pido! Busca una salida!" ) ;
			}
			catch (PortalException e){
				System . out . println ( e.getMessage() ) ;
			}
			}
			else {
				System . out . println ( "Uhmmm esto es portal 2!" ) ;
				throw new PortalException ( "Huyendo de Wheatley" ) ;
			}
			} catch (Exception e){
				System . out . println ( "GLaDOs no funciona" ) ;
			}
			finally {
				System . out . println ( "Finalizando nivel!" ) ;
			}
		}
	
	
		public static void portal1 ( String OSname , int level ) throws PortalException {
		try{
			portal2 ( level );
		}
		catch (Exception e){
			System . out . println ( "Ni idea de cu�l es esta excepci�n" ) ;
			throw new PortalException ( "Error en GLaDOs!" ) ;
		}
			System . out . println ( "Saliendo de portal 1" ) ;
		}
		
		
		
		public static void portal2 ( int currentLevel ){
			if ( currentLevel %2==0)
				System . out . println ( "Estamos en un nivel par" ) ;
			else {
				System . out . println ( "--->" + currentLevel /( currentLevel - 1) ) ;
			}
		}
		
}


