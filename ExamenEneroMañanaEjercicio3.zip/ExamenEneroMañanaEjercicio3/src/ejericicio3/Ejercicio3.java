package ejericicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		// Apartado 1
		BigBoss bb = new BigBoss ();
		bb.addAttack(5);
		bb.addAttack(15);
		
		
		Snake solidSnake = new Snake("Solid Snake");
		bb.addAttack(10);
		solidSnake.block();
		System.out.println ("Solid Snake�s cqc = " + solidSnake.getCqc());
		
		
		// Apartado 2
		Ocelot ocelot = new Ocelot ();
		Snake liquidSnake = new Snake("Liquid Snake");
		liquidSnake.addAttack(12);
		ocelot.fight(liquidSnake);
		
		
		Snake solidusSnake = new Snake("Solidus Snake");
		solidusSnake.addAttack(17);
		ocelot.fight(solidusSnake);
		
	/*	VARIABLE DUPLICADA
		Snake solidSnake = new Snake("Solid Snake");*/
		solidSnake.addAttack(22);
		ocelot.fight(solidSnake);
		
		
		System.out.println ("cqc de Liquid Snake = " + liquidSnake.getCqc() +
		" - ataque: " + liquidSnake.calculateAttack());
		System.out.println ("cqc de Solidus Snake = " + solidusSnake.getCqc() +
		" - ataque: " + solidusSnake.calculateAttack());
		System.out.println ("cqc de Solid Snake = " + solidSnake.getCqc() +
		" - ataque: " + solidSnake.calculateAttack());
		}
	
}
