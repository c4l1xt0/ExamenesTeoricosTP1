package ejericicio3;

public class Snake extends BigBoss {
	
	private String name ;
	public Snake ( String name ) {
		this.name = name ;
		cqcLevel = cqcLevel+5 ;
	}
	public void block () {
		if ( cqcLevel %2 == 0 )
			System . out . println (name + " bloquea un ataque!" ) ;
	else
		System . out . println (name + " recibe un ataque!" ) ;
	}
	
}
