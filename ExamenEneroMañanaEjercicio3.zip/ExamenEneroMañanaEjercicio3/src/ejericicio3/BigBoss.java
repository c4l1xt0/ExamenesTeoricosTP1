package ejericicio3;

public class BigBoss {
	
	protected static int cqcLevel = 10;
	private int attacks [];
	private int counter = 0;
	
	public BigBoss () {
		attacks = new int [5];
	}
	
	public int getCqc () {
		return cqcLevel ;
	}
	
	public void addAttack ( int x){
		attacks[counter++] = x ;
	}
	
	public int calculateAttack (){
		int a=0;
		for ( int i =0; i<counter ; i++)
			if ( cqcLevel >= attacks[i] )
				a += attacks[i] ;
		return a ;
	}
}
