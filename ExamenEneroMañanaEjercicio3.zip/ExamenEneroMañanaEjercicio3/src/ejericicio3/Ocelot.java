package ejericicio3;

public class Ocelot {
	private int cqcLevel ;
	
	public Ocelot (){
		cqcLevel = 25;
	}
	
	public void fight ( BigBoss bb ) {
		if ( bb.getCqc ( ) >= this . cqcLevel )
			System . out . println ( "Snake gana..." ) ;
		else	System . out . println ( "Ocelot gana..." ) ;
	}
}
