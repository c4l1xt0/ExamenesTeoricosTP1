package paqueton;

public class FlyingNeo extends Neo {
	
	public FlyingNeo () {
		this . version = "FlyingNeo" ;
	}
	
}
