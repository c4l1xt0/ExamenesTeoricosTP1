package paqueton;

public class Ejercicio5 {

	public static void main(String[] args) {
		Matrix matrices [];
		Neo neo, otroNeo;
		matrices = new Matrix[3];
		matrices[0] = new Matrix();
		matrices[1] = new Matrix2("Matrix 2");
		matrices[2] = new Matrix4("Matrix 4");
		
		neo = new Neo();
		otroNeo = new FlyingNeo();
		// Apartado 1
		System.out.println (neo.getVersion());
		System.out.println (otroNeo.getVersion());
		for (int i=0; i<matrices.length; i++)
			System.out.println (matrices[i].argumento(neo));
		// Apartado 2
		for (int i=0; i<matrices.length; i++)
			matrices[i].liberarMatrix(neo);
		// Apartado 3
		for (int i=0; i<matrices.length; i++)
			matrices[i].liberarMatrix(otroNeo);
		((Matrix) matrices[0]).liberarMatrix(neo);
		((Matrix2) matrices[1]).liberarMatrix(neo);
		((Matrix4) matrices[2]).liberarMatrix(neo);
		}
	
	
}
