package paqueton;

public class Neo {
	
	protected String version ;
	
	public Neo ( ) {
		version = "El elegido" ;
	}
	
	public String getVersion () {
		return this.version ;
	}
	
}
