package paqueton;

public class Matrix4 extends Matrix2{
	public Matrix4 ( String title ) {
		this . title = title + " ya no hay arquitecto , ahora es un analista!" ;
		}
		public Neo liberarMatrix ( FlyingNeo elSuperElegido ) {
		System . out . println ( elSuperElegido . getVersion () + " salvando Matrix 4 con Trinity" ) ;
		return new Neo ( ) ;
		}
		public String argumento (Neo elElegido ) {
		return elElegido.getVersion () + " pero en " + title ;
		}
}
