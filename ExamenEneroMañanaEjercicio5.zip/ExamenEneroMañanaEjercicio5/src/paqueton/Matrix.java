package paqueton;

public class Matrix {

	protected String title ;
	
	public Matrix () {
		title = "Matrix" ;
	}
	public Neo liberarMatrix (Neo elElegido ) {
		
		System.out.println ( elElegido . getVersion () + " salvando Matrix 1" ) ;
		return new Neo ( );
		
	}
	
	public Object argumento (Neo elElegido) {
		
		return elElegido.getVersion () + " -> " + title;
		
	}
	
}
