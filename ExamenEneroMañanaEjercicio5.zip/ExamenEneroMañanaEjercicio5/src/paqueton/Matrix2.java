package paqueton;

public class Matrix2 extends Matrix{

	public Matrix2 () {}
	
	public Matrix2 ( String title ) {
		this.title = title + ", el arquitecto la va a liar" ;
	}
	public Neo liberarMatrix ( Object o ) {
		System . out . println ( "Alguien intenta salvar Matrix 2!" ) ;
		return new Neo ( ) ;
	}
	
}
